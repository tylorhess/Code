This plugin/addon needs to be uploaded to the "/wp-content/plugins/" directory on your server or installed using the WordPress plugins installer.

Once the plugin/addon is installed nad activated you will have a "Member Settings" tab in the left menu of your WordPress admin under the "Event Manager" tab. To make an event a "Member Only" event. Edit the event and choose Yes in the "Is this a member only event?" under the "Attendees" section of the event editor.

Member Settings Page:
This page will allow you to do the following.
	- Choose a Login page (if different from default Wordpress login page) used for the link that will appear if a member is not logged in and trying to access a memebr only event.
	- Choose a Member registration page (if different from default Wordpress register page) used for the link that will appear if a member is not logged in and trying to access a memebr only event.
	- Require login for all events? Allows you to make all of your events, member only events.
	
