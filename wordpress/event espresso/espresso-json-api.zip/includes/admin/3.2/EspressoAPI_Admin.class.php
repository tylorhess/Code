<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of EspressoAPI_Admin
 *
 * @author mnelson4
 */
class EspressoAPI_Admin {
	//put your code here
}

?>
