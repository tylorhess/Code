<?php
if (file_exists(EVENT_ESPRESSO_GATEWAY_DIR . "/index.php")) {
?>
<ul><li>
		<div class="metabox-holder">
			<div class="postbox">
				<h3>
					<?php _e("Developers Section", 'event_espresso'); ?>
				</h3>

				<div class="padding">
					
						<p class="red_alert">
							<?php _e('Remember, if updates are made or features are added to these gateways in the future. You will need to make the updates to your customized gateways.', 'event_espresso'); ?>
						</p>

				</div>
			</div>
		</div>
	</li></ul>
<?php } ?>